(function ($) {
	$.fn.scannerDetection = function (options) {
		function getScannerSpeed() {
			let configTable = WPOS.getConfigTable();
			let scannerspeed = configTable && configTable.general ? configTable.general.scanner_speed : undefined;
			if (!scannerspeed) {
				console.log('scannerspeed not found default to 100');
				scannerspeed = 100
			}
			scannerspeed = parseInt(scannerspeed);
			return scannerspeed
		}

		const scannerspeed = getScannerSpeed();




		if (!window.scannerdetection) window.scannerdetection = {};


		// Generate a unique namespace for event handlers
		let namespace = '.scannerDetection' + Date.now() + Math.random();

		if (options && options.namespace) {
			namespace = '.scannerDetection' + `.${options.namespace}`;
		}

		if (window.scannerdetection && window.scannerdetection[namespace]) {
			return;
		}
		else {
			if (!window.scannerdetection) window.scannerdetection = {};
			else window.scannerdetection[namespace] = true;
		}



		// Default settings
		const defaults = {
			onComplete: false, // Callback after successful scan
			onError: false,    // Callback after error
			onReceive: false,  // Callback after receiving each character
			onKeyDetect: false,// Callback after detecting each key
			avgTimeByChar: scannerspeed, // Adjusted average time between characters
			minLength: 4,      // Minimum length for a valid scan

			startChar: [],     // Start characters
			ignoreIfFocusOn: false, // Ignore scan if focus is on specified element(s)
			scanButtonKeyCode: false, // Key code for scan button
			scanButtonLongPressThreshold: 3, // Threshold for long press
			onScanButtonLongPressed: false,  // Callback for long press
			stopPropagation: false,
			preventDefault: false
		};



		if (typeof options === "function") {
			options = { onComplete: options };
		}

		options = { ...defaults, ...options };

		// Derived options
		const avgTimeMultiplier = 1.3; // Multiplier for acceptable time between chars
		const timeBeforeScanTest = 100; // Time before testing scan

		this.each(function () {
			const element = this;
			const $element = $(element);



			// Instance-specific variables
			let firstCharTime = 0;
			let lastCharTime = 0;
			let stringWriting = '';
			let testTimer = null;
			let scanButtonCounter = 0;
			let timeBetweenChars = [];

			const initScannerDetection = () => {
				firstCharTime = 0;
				lastCharTime = 0;
				stringWriting = '';
				scanButtonCounter = 0;
				timeBetweenChars = [];
				if (testTimer) {
					clearTimeout(testTimer);
					testTimer = null;
				}
			};

			const isFocusOnIgnoredElement = () => {
				if (!options.ignoreIfFocusOn) return false;
				const focusedElement = document.activeElement;
				if (!focusedElement) return false;

				if (typeof options.ignoreIfFocusOn === 'string') {
					return $(focusedElement).is(options.ignoreIfFocusOn);
				}

				if (Array.isArray(options.ignoreIfFocusOn)) {
					return options.ignoreIfFocusOn.some(selector => $(focusedElement).is(selector));
				}

				return false;
			};

			const scannerDetectionTest = () => {
				if (stringWriting.length >= options.minLength) {
					if (timeBetweenChars.length > 0) {
						const adjustedAvgTimeByChar = options.avgTimeByChar * avgTimeMultiplier;
						const allUnderThreshold = timeBetweenChars.every(
							timeDiff => timeDiff <= adjustedAvgTimeByChar
						);

						if (allUnderThreshold) {
							// Valid scan detected
							if (
								options.onScanButtonLongPressed &&
								scanButtonCounter > options.scanButtonLongPressThreshold
							) {
								options.onScanButtonLongPressed.call(element, stringWriting, scanButtonCounter);
							} else if (options.onComplete) {
								options.onComplete.call(element, stringWriting, element);
							}
							const event = new CustomEvent('scannerDetectionComplete', { detail: { string: stringWriting } });
							element.dispatchEvent(event);
							initScannerDetection();
							return true;
						} else {
							// Timing between chars too long; reset the state
							if (options.onError) options.onError.call(element, stringWriting);
							const event = new CustomEvent('scannerDetectionError', { detail: { string: stringWriting } });
							element.dispatchEvent(event);
							initScannerDetection();
							return false;
						}
					} else {
						// Not enough data to determine scan; reset the state
						if (options.onError) options.onError.call(element, stringWriting);
						const event = new CustomEvent('scannerDetectionError', { detail: { string: stringWriting } });
						element.dispatchEvent(event);
						initScannerDetection();
						return false;
					}
				} else {
					// String too short; reset the state
					if (options.onError) options.onError.call(element, stringWriting);
					const event = new CustomEvent('scannerDetectionError', { detail: { string: stringWriting } });
					element.dispatchEvent(event);
					initScannerDetection();
					return false;
				}
			};

			const keydownHandler = function (e) {
				if (options.scanButtonKeyCode !== false && e.keyCode == options.scanButtonKeyCode) {
					scanButtonCounter++;
					e.preventDefault();
					e.stopImmediatePropagation();
				}

				if (options.onKeyDetect) options.onKeyDetect.call(element, e);
				const event = new CustomEvent('scannerDetectionKeyDetect', { detail: { evt: e } });
				element.dispatchEvent(event);
			};

			const keypressHandler = function (e) {
				if (isFocusOnIgnoredElement()) {
					// Reset the state if focus is on an ignored element
					initScannerDetection();
					return;
				}

				if (options.stopPropagation) e.stopImmediatePropagation();
				if (options.preventDefault) e.preventDefault();

				if (typeof e.key !== 'undefined') {

					const char = e.key;
					if (char.length === 1 && e.key !== '?' && e.key !== ' ' && e.key !== '\t' && e.key !== '\n') {
						// Only process if character is a single character and not tab, return, or space
						stringWriting += char;
						const currentTime = Date.now();
						if (!firstCharTime) {
							firstCharTime = currentTime;
							lastCharTime = currentTime;
						} else {
							const timeDiff = currentTime - lastCharTime;
							timeBetweenChars.push(timeDiff);
							lastCharTime = currentTime;
						}

						if (testTimer) {
							clearTimeout(testTimer);
						}

						testTimer = setTimeout(function () {
							scannerDetectionTest();
						}, timeBeforeScanTest);

						if (options.onReceive) {
							options.onReceive.call(element, e);
						}
						const event = new CustomEvent('scannerDetectionReceive', { detail: { evt: e } });
						element.dispatchEvent(event);
					}
				}

				if (options.onKeyDetect) options.onKeyDetect.call(element, e);
				const event = new CustomEvent('scannerDetectionKeyDetect', { detail: { evt: e } });
				element.dispatchEvent(event);
			};

			// Attach event listeners with namespace
			$element.on('keydown' + namespace, keydownHandler);
			$element.on('keypress' + namespace, keypressHandler);

			// Provide a method to remove this instance's event handlers
			$element.data('scannerDetectionOff' + namespace, function () {
				$element.off(namespace);
			});
		});

		return this;
	};
})(jQuery);
